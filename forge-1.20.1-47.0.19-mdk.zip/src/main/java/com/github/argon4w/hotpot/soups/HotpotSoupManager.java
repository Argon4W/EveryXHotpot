package com.github.argon4w.hotpot.soups;

import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.SimpleJsonResourceReloadListener;
import net.minecraft.util.profiling.ProfilerFiller;
import net.minecraftforge.common.crafting.conditions.ICondition;

import java.util.HashMap;
import java.util.Map;

public class HotpotSoupManager extends SimpleJsonResourceReloadListener {
    public static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().disableHtmlEscaping().create();
    private final ICondition.IContext context;
    private final HashMap<ResourceLocation, AbstractHotpotSoupVariant> soupVariants;

    public HotpotSoupManager(ICondition.IContext context) {
        super(HotpotSoupManager.GSON, "soups");
        this.context = context;
        this.soupVariants = Maps.newHashMap();
    }

    @Override
    protected void apply(Map<ResourceLocation, JsonElement> p_10793_, ResourceManager p_10794_, ProfilerFiller p_10795_) {

    }
}
