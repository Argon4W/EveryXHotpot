package com.github.argon4w.hotpot.client.soups;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import org.apache.commons.compress.utils.Lists;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class HotpotSoupRendererConfig {
    public static final Serializer SERIALIZER = new Serializer();

    private final ResourceLocation soupModelResourceLocation;
    private final List<IHotpotSoupCustomElementRenderer> customElementRenderers;

    public HotpotSoupRendererConfig(ResourceLocation soupModelResourceLocation, List<IHotpotSoupCustomElementRenderer> customElementRenderers) {
        this.soupModelResourceLocation = soupModelResourceLocation;
        this.customElementRenderers = customElementRenderers;
    }

    public Optional<ResourceLocation> getSoupModelResourceLocation() {
        return Optional.ofNullable(soupModelResourceLocation);
    }

    public List<IHotpotSoupCustomElementRenderer> getCustomElementRenderers() {
        return customElementRenderers;
    }

    public static class Serializer {
        public HotpotSoupRendererConfig fromJson(JsonObject jsonObject) {
            if (jsonObject.has("soup_model_resource_location") && !ResourceLocation.isValidResourceLocation(GsonHelper.getAsString(jsonObject, "soup_model_resource_location"))) {
                throw new JsonParseException("\"soup_model_resource_location\" in the soup renderer config must be a valid resource location");
            }

            ResourceLocation soupModelResourceLocation = null;
            ArrayList<IHotpotSoupCustomElementRenderer> customElements = Lists.newArrayList();

            if (jsonObject.has("soup_model_resource_location")) {
                soupModelResourceLocation = new ResourceLocation(GsonHelper.getAsString(jsonObject, "soup_model_resource_location"));
            }

            if (!jsonObject.has("custom_elements_renderers")) {
                return new HotpotSoupRendererConfig(soupModelResourceLocation, customElements);
            }

            for (JsonElement jsonElement : GsonHelper.getAsJsonArray(jsonObject, "custom_elements_renderers")) {
                if (!jsonElement.isJsonObject()) {
                    throw new JsonParseException("Custom element renderer in the soup renderer config must be a JSON object");
                }

                JsonObject customRendererJsonObject = jsonObject.getAsJsonObject();

                if (!customRendererJsonObject.has("type")) {
                    throw new JsonParseException("Custom element renderer in the soup renderer config must have a \"type\"");
                }

                if (!ResourceLocation.isValidResourceLocation(GsonHelper.getAsString(customRendererJsonObject, "type"))) {
                    throw new JsonParseException("\"type\" in the custom element renderer must be a valid resource location");
                }

                ResourceLocation customElementRendererResourceLocation = new ResourceLocation(GsonHelper.getAsString(customRendererJsonObject, "type"));
                IHotpotSoupCustomElementRendererSerializer<?> serializer = HotpotSoupCustomElements.getCustomElementSerializer(customElementRendererResourceLocation);

                customElements.add(serializer.fromJson(customRendererJsonObject));
            }

            return new HotpotSoupRendererConfig(soupModelResourceLocation, customElements);
        }
    }
}