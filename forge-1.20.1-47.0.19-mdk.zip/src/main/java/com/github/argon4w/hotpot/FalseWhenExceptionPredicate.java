package com.github.argon4w.hotpot;

import java.util.function.Predicate;

@FunctionalInterface
public interface FalseWhenExceptionPredicate<T> {
    boolean test(T t) throws Exception;

    static <T> Predicate<T> of(FalseWhenExceptionPredicate<T> predicate) {
        return t -> {
            try {
                return predicate.test(t);
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        };
    }
}
