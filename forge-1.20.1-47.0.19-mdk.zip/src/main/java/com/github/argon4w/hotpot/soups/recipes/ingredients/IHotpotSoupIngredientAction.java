package com.github.argon4w.hotpot.soups.recipes.ingredients;

import com.github.argon4w.hotpot.BlockPosWithLevel;
import com.github.argon4w.hotpot.contents.IHotpotContent;
import com.github.argon4w.hotpot.soups.IHotpotSoup;

public interface IHotpotSoupIngredientAction {
    IHotpotContent action(BlockPosWithLevel pos, IHotpotContent content, IHotpotSoup source, IHotpotSoup target);
    IHotpotSoupIngredientActionSerializer<?> getSerializer();
}
