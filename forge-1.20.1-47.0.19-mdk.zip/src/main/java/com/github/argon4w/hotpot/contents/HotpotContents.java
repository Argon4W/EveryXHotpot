package com.github.argon4w.hotpot.contents;

import com.github.argon4w.hotpot.HotpotModEntry;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.Container;
import net.minecraft.world.item.crafting.BlastingRecipe;
import net.minecraft.world.item.crafting.CampfireCookingRecipe;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryBuilder;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.Supplier;

public class HotpotContents {
    public static final RecipeManager.CachedCheck<Container, CampfireCookingRecipe> CAMPFIRE_QUICK_CHECK = RecipeManager.createCheck(RecipeType.CAMPFIRE_COOKING);
    public static final RecipeManager.CachedCheck<Container, BlastingRecipe> BLAST_FURNACE_QUICK_CHECK = RecipeManager.createCheck(RecipeType.BLASTING);

    public static final ResourceLocation EMPTY_CONTENT_LOCATION = new ResourceLocation(HotpotModEntry.MODID, "empty_content");

    public static final ResourceKey<Registry<HotpotContentHolder<?>>> CONTENT_REGISTRY_KEY = ResourceKey.createRegistryKey(new ResourceLocation(HotpotModEntry.MODID, "content"));
    public static final DeferredRegister<HotpotContentHolder<?>> CONTENTS = DeferredRegister.create(CONTENT_REGISTRY_KEY, HotpotModEntry.MODID);
    public static final Supplier<IForgeRegistry<HotpotContentHolder<?>>> CONTENT_REGISTRY = CONTENTS.makeRegistry(() -> new RegistryBuilder<HotpotContentHolder<?>>().setDefaultKey(EMPTY_CONTENT_LOCATION));

    public static final RegistryObject<HotpotContentHolder<HotpotCookingRecipeContent>> CAMPFIRE_RECIPE_CONTENT = CONTENTS.register("cooking_recipe_content", () -> HotpotCookingRecipeContent::new);
    public static final RegistryObject<HotpotContentHolder<HotpotSmeltingRecipeContent>> BLASTING_RECIPE_CONTENT = CONTENTS.register("smelting_recipe_content", () -> HotpotSmeltingRecipeContent::new);
    public static final RegistryObject<HotpotContentHolder<HotpotPlayerContent>> PLAYER_CONTENT = CONTENTS.register("player_content", () -> HotpotPlayerContent::new);
    public static final RegistryObject<HotpotContentHolder<HotpotEmptyContent>> EMPTY_CONTENT = CONTENTS.register("empty_content", () -> HotpotEmptyContent::new);

    public static HotpotContentHolder<HotpotEmptyContent> getEmptyContent() {
        return () -> EMPTY_CONTENT.get().createContent();
    }

    public static IForgeRegistry<HotpotContentHolder<?>> getContentRegistry() {
        return CONTENT_REGISTRY.get();
    }

    public static HotpotContentHolder<?> getContentType(ResourceLocation resourceLocation) {
        return getContentRegistry().getValue(resourceLocation);
    }
}
