package com.github.argon4w.hotpot.soups;

import com.github.argon4w.hotpot.BlockPosWithLevel;
import com.github.argon4w.hotpot.HotpotTagsHelper;
import com.github.argon4w.hotpot.blocks.HotpotBlockEntity;
import com.github.argon4w.hotpot.client.soups.HotpotSoupCustomElements;
import com.github.argon4w.hotpot.client.soups.HotpotSoupRendererConfig;
import com.github.argon4w.hotpot.client.soups.IHotpotSoupCustomElementRenderer;
import com.github.argon4w.hotpot.client.soups.IHotpotSoupCustomElementRendererSerializer;
import com.github.argon4w.hotpot.contents.HotpotCookingRecipeContent;
import com.github.argon4w.hotpot.contents.IHotpotContent;
import com.github.argon4w.hotpot.soups.effects.HotpotEffectHelper;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.crafting.CraftingHelper;
import org.apache.commons.compress.utils.Lists;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class HotpotCookingRecipeSoup extends AbstractHotpotFluidBasedSoup {
    private final ResourceLocation resourceLocation;
    private final float waterLevelDropRate;
    private final List<MobEffectInstance> effects;

    public HotpotCookingRecipeSoup(ResourceLocation resourceLocation, float waterLevelDropRate, List<MobEffectInstance> effects) {
        this.resourceLocation = resourceLocation;
        this.waterLevelDropRate = waterLevelDropRate;
        this.effects = effects;
    }

    @Override
    public ItemStack takeOutContentViaChopstick(IHotpotContent content, ItemStack itemStack, HotpotBlockEntity hotpotBlockEntity, BlockPosWithLevel pos) {
        ItemStack result = super.takeOutContentViaChopstick(content, itemStack, hotpotBlockEntity, pos);

        if (content instanceof HotpotCookingRecipeContent cookingContent && cookingContent.getFoodProperties().isPresent() && cookingContent.getCookingTime() < 0) {
            effects.forEach(effect -> HotpotEffectHelper.saveEffects(result, effect));
        }

        return result;
    }

    @Override
    public void animateTick(HotpotBlockEntity hotpotBlockEntity, BlockPosWithLevel pos, RandomSource randomSource) {

    }

    @Override
    public Optional<IHotpotContent> remapItemStack(boolean copy, ItemStack itemStack, BlockPosWithLevel pos) {
        return Optional.of(new HotpotCookingRecipeContent((copy ? itemStack.copy() : itemStack)));
    }

    @Override
    public ResourceLocation getID() {
        return resourceLocation;
    }

    @Override
    public float getWaterLevelDropRate() {
        return waterLevelDropRate;
    }

    public static class Cheese extends HotpotCookingRecipeSoup {
        public Cheese(ResourceLocation resourceLocation, float waterLevelDropRate, List<MobEffectInstance> effects) {
            super(resourceLocation, waterLevelDropRate, effects);
        }

        @Override
        public ItemStack takeOutContentViaChopstick(IHotpotContent content, ItemStack itemStack, HotpotBlockEntity hotpotBlockEntity, BlockPosWithLevel pos) {
            HotpotTagsHelper.updateHotpotTag(itemStack, compoundTag -> compoundTag.putBoolean("Cheesed", true));
            return super.takeOutContentViaChopstick(content, itemStack, hotpotBlockEntity, pos);
        }
    }

    public static class Serializer implements IHotpotSoupSerializer<HotpotCookingRecipeSoup> {
        @Override
        public HotpotCookingRecipeSoup fromJson(ResourceLocation resourceLocation, JsonObject jsonObject) {
            if (!jsonObject.has("water_level_drop_rate")) {
                throw new JsonParseException("Cooking recipe soup must have a \"water_level_drop_rate\"");
            }

            float waterLevelDropRate = GsonHelper.getAsFloat(jsonObject, "water_level_drop_rate");
            boolean cheese = jsonObject.has("cheese") && GsonHelper.getAsBoolean(jsonObject, "cheese");
            ArrayList<MobEffectInstance> effects = Lists.newArrayList();

            if (!jsonObject.has("effects")) {
                return new HotpotCookingRecipeSoup(resourceLocation, waterLevelDropRate, effects);
            }

            for (JsonElement jsonElement : GsonHelper.getAsJsonArray(jsonObject, "effects")) {
                if (!jsonElement.isJsonObject()) {
                    throw new JsonParseException("Mob effect must be a JSON object");
                }

                JsonObject mobEffectJsonObject = jsonObject.getAsJsonObject();
                effects.add(MobEffectInstance.load(CraftingHelper.getNBT(mobEffectJsonObject)));
            }

            return cheese ? new Cheese(resourceLocation, waterLevelDropRate, effects) : new HotpotCookingRecipeSoup(resourceLocation, waterLevelDropRate, effects);
        }
    }
}