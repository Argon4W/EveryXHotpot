package com.github.argon4w.hotpot.contents;

import com.github.argon4w.hotpot.BlockPosWithLevel;
import com.github.argon4w.hotpot.HotpotModEntry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.CampfireCookingRecipe;

import java.util.Optional;

public class HotpotCookingRecipeContent extends AbstractHotpotRecipeContent {
    public HotpotCookingRecipeContent(ItemStack itemStack) {
        super(itemStack);
    }

    public HotpotCookingRecipeContent() {
        super();
    }

    @Override
    public Optional<CampfireCookingRecipe> getRecipe(ItemStack itemStack, BlockPosWithLevel pos) {
        return HotpotContents.CAMPFIRE_QUICK_CHECK.getRecipeFor(new SimpleContainer(itemStack), pos.level());
    }

    @Override
    public ResourceLocation getID() {
        return new ResourceLocation(HotpotModEntry.MODID, "campfire_recipe_content");
    }
}
