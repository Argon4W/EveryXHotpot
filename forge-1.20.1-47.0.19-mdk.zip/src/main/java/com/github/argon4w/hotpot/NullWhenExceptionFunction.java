package com.github.argon4w.hotpot;

import java.util.function.Function;
import java.util.function.Predicate;

@FunctionalInterface
public interface NullWhenExceptionFunction<T, R> {
    R apply(T t) throws Exception;

    static <T, R> Function<T, R> of(NullWhenExceptionFunction<T, R> function) {
        return t -> {
            try {
                return function.apply(t);
            } catch (Exception e) {
                e.printStackTrace();
                return null;
            }
        };
    }
}
