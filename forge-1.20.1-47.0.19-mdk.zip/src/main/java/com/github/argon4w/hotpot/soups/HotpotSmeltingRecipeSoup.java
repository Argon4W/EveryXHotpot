package com.github.argon4w.hotpot.soups;

import com.github.argon4w.hotpot.BlockPosWithLevel;
import com.github.argon4w.hotpot.HotpotModEntry;
import com.github.argon4w.hotpot.blocks.HotpotBlockEntity;
import com.github.argon4w.hotpot.contents.HotpotSmeltingRecipeContent;
import com.github.argon4w.hotpot.contents.IHotpotContent;
import com.github.argon4w.hotpot.client.soups.IHotpotSoupCustomElementRenderer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.common.crafting.CraftingHelper;
import org.apache.commons.compress.utils.Lists;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class HotpotSmeltingRecipeSoup extends AbstractHotpotFluidBasedSoup {
    private final ResourceLocation resourceLocation;
    private final float waterLevelDropRate;

    public HotpotSmeltingRecipeSoup(ResourceLocation resourceLocation, float waterLevelDropRate) {
        this.resourceLocation = resourceLocation;
        this.waterLevelDropRate = waterLevelDropRate;
    }

    @Override
    public Optional<IHotpotContent> remapItemStack(boolean copy, ItemStack itemStack, BlockPosWithLevel pos) {
        return HotpotSmeltingRecipeContent.hasBlastingRecipe(itemStack, pos) ? Optional.of(new HotpotSmeltingRecipeContent((copy ? itemStack.copy() : itemStack))) : Optional.empty();
    }

    @Override
    public void animateTick(HotpotBlockEntity hotpotBlockEntity, BlockPosWithLevel pos, RandomSource randomSource) {

    }

    @Override
    public float getWaterLevelDropRate() {
        return waterLevelDropRate;
    }

    @Override
    public ResourceLocation getID() {
        return resourceLocation;
    }

    public static class Serializer implements IHotpotSoupSerializer<HotpotSmeltingRecipeSoup> {
        @Override
        public HotpotSmeltingRecipeSoup fromJson(ResourceLocation resourceLocation, JsonObject jsonObject) {
            if (!jsonObject.has("water_level_drop_rate")) {
                throw new JsonParseException("Cooking recipe soup must have a \"water_level_drop_rate\"");
            }

            float waterLevelDropRate = GsonHelper.getAsFloat(jsonObject, "water_level_drop_rate");


            return new HotpotSmeltingRecipeSoup(resourceLocation, waterLevelDropRate);
        }
    }
}
