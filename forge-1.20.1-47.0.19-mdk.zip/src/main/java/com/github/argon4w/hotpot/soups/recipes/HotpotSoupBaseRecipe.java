package com.github.argon4w.hotpot.soups.recipes;

import com.github.argon4w.hotpot.HotpotModEntry;
import com.github.argon4w.hotpot.soups.HotpotSoups;
import com.github.argon4w.hotpot.soups.IHotpotSoup;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.ShapedRecipe;
import org.jetbrains.annotations.Nullable;

public class HotpotSoupBaseRecipe extends AbstractHotpotSoupRecipe {
    private final ResourceLocation location;
    private final ResourceLocation sourceSoup;
    private final ResourceLocation resultSoup;
    private final float resultWaterLevel;
    private final Ingredient ingredient;
    private final ItemStack remainingItem;
    private final ResourceLocation soundEvent;

    public HotpotSoupBaseRecipe(ResourceLocation location, ResourceLocation sourceSoup, ResourceLocation resultSoup, float resultWaterLevel, Ingredient ingredient, ItemStack remainingItem, ResourceLocation soundEvent) {
        this.location = location;
        this.sourceSoup = sourceSoup;
        this.resultSoup = resultSoup;
        this.resultWaterLevel = resultWaterLevel;
        this.ingredient = ingredient;
        this.remainingItem = remainingItem;
        this.soundEvent = soundEvent;
    }

    public boolean matches(ItemStack itemStack) {
        return ingredient.test(itemStack);
    }

    public ItemStack getRemainingItem() {
        return remainingItem;
    }

    public ResourceLocation getSourceSoup() {
        return sourceSoup;
    }

    public IHotpotSoup createResultSoup() {
        return HotpotSoups.getSoupType(resultSoup).createSoup();
    }

    public ResourceLocation getSoundEvent() {
        return soundEvent;
    }

    public float getResultWaterLevel() {
        return resultWaterLevel;
    }

    @Override
    public ResourceLocation getId() {
        return location;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return HotpotModEntry.HOTPOT_SOUP_BASE_RECIPE_SERIALIZER.get();
    }

    @Override
    public RecipeType<?> getType() {
        return HotpotModEntry.HOTPOT_SOUP_BASE_RECIPE_TYPE.get();
    }

    public static class Serializer implements RecipeSerializer<HotpotSoupBaseRecipe> {
        @Override
        public HotpotSoupBaseRecipe fromJson(ResourceLocation location, JsonObject jsonObject) {
            if (!jsonObject.has("source_soup")) {
                throw new JsonParseException("Base soup recipe must have a \"source_soup\"");
            }

            if (!jsonObject.has("result_soup")) {
                throw new JsonParseException("Base soup recipe must have a \"result_soup\"");
            }

            if (!jsonObject.has("result_waterlevel")) {
                throw new JsonParseException("Base soup recipe must have a \"result_waterlevel\"");
            }

            if (!jsonObject.has("ingredient")) {
                throw new JsonParseException("Base soup recipe must have a \"ingredient\"");
            }

            /*if (!jsonObject.has("remaining_item")) {
                throw new JsonParseException("Base soup recipe must have a \"remaining_item\"");
            }*/

            if (!jsonObject.has("sound_event")) {
                throw new JsonParseException("Base soup recipe must have a \"remaining_item\"");
            }

            return new HotpotSoupBaseRecipe(
                    location,
                    new ResourceLocation(GsonHelper.getAsString(jsonObject, "source_soup")),
                    new ResourceLocation(GsonHelper.getAsString(jsonObject, "result_soup")),
                    GsonHelper.getAsFloat(jsonObject, "result_waterlevel"),
                    Ingredient.fromJson(GsonHelper.getAsJsonObject(jsonObject, "ingredient")),
                    jsonObject.has("remaining_item") ? new ItemStack(ShapedRecipe.itemFromJson(GsonHelper.getAsJsonObject(jsonObject, "remaining_item"))) : ItemStack.EMPTY,
                    ResourceLocation.tryParse(GsonHelper.getAsString(jsonObject, "sound_event"))
            );
        }

        @Override
        public @Nullable HotpotSoupBaseRecipe fromNetwork(ResourceLocation location, FriendlyByteBuf byteBuf) {
            ResourceLocation sourceSoup = byteBuf.readResourceLocation();
            ResourceLocation resultSoup = byteBuf.readResourceLocation();
            float resultWaterLevel = byteBuf.readFloat();
            Ingredient ingredient = Ingredient.fromNetwork(byteBuf);
            ItemStack remainingItem = byteBuf.readItem();
            ResourceLocation soundEvent = byteBuf.readResourceLocation();

            return new HotpotSoupBaseRecipe(location, sourceSoup, resultSoup, resultWaterLevel, ingredient, remainingItem, soundEvent);
        }

        @Override
        public void toNetwork(FriendlyByteBuf byteBuf, HotpotSoupBaseRecipe recipe) {
            byteBuf.writeResourceLocation(recipe.sourceSoup);
            byteBuf.writeResourceLocation(recipe.resultSoup);
            byteBuf.writeFloat(recipe.resultWaterLevel);
            recipe.ingredient.toNetwork(byteBuf);
            byteBuf.writeItem(recipe.remainingItem);
            byteBuf.writeResourceLocation(recipe.soundEvent);
        }
    }
}
