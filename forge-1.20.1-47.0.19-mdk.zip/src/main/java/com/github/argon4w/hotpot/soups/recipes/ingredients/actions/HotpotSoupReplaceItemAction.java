package com.github.argon4w.hotpot.soups.recipes.ingredients.actions;

import com.github.argon4w.hotpot.BlockPosWithLevel;
import com.github.argon4w.hotpot.HotpotModEntry;
import com.github.argon4w.hotpot.contents.HotpotContents;
import com.github.argon4w.hotpot.contents.IHotpotContent;
import com.github.argon4w.hotpot.soups.IHotpotSoup;
import com.github.argon4w.hotpot.soups.recipes.ingredients.HotpotSoupIngredients;
import com.github.argon4w.hotpot.soups.recipes.ingredients.IHotpotSoupIngredientAction;
import com.github.argon4w.hotpot.soups.recipes.ingredients.IHotpotSoupIngredientActionSerializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.ShapedRecipe;

public record HotpotSoupReplaceItemAction(ItemStack itemStack) implements IHotpotSoupIngredientAction {
    @Override
    public IHotpotContent action(BlockPosWithLevel pos, IHotpotContent content, IHotpotSoup source, IHotpotSoup target) {
        return target.remapItemStack(true, itemStack, pos).orElse(HotpotContents.getEmptyContent().createContent());
    }

    @Override
    public IHotpotSoupIngredientActionSerializer<?> getSerializer() {
        return HotpotSoupIngredients.REPLACE_ACTION_SERIALIZER.get();
    }

    public static class Serializer implements IHotpotSoupIngredientActionSerializer<HotpotSoupReplaceItemAction> {
        @Override
        public HotpotSoupReplaceItemAction fromJson(JsonObject jsonObject) {
            if (!jsonObject.has("result")) {
                throw new JsonParseException("Replace assembler must have a \"result\"");
            }

            return new HotpotSoupReplaceItemAction(ShapedRecipe.itemStackFromJson(GsonHelper.getAsJsonObject(jsonObject, "result")).copyWithCount(1));
        }

        @Override
        public HotpotSoupReplaceItemAction fromNetwork(FriendlyByteBuf byteBuf) {
            return new HotpotSoupReplaceItemAction(byteBuf.readItem());
        }

        @Override
        public void toNetwork(FriendlyByteBuf byteBuf, HotpotSoupReplaceItemAction action) {
            byteBuf.writeItem(action.itemStack);
        }

        @Override
        public ResourceLocation getType() {
            return new ResourceLocation(HotpotModEntry.MODID, "replace");
        }
    }
}
