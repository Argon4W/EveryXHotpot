package com.github.argon4w.hotpot.soups;

import com.google.gson.JsonObject;
import net.minecraft.resources.ResourceLocation;

public interface IHotpotSoupSerializer<T extends IHotpotSoup> {
    T fromJson(ResourceLocation resourceLocation, JsonObject jsonObject);
}
