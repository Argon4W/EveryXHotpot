package com.github.argon4w.hotpot.soups.recipes.ingredients.conditions;

import com.github.argon4w.hotpot.HotpotModEntry;
import com.github.argon4w.hotpot.contents.IHotpotContent;
import com.github.argon4w.hotpot.soups.IHotpotSoup;
import com.github.argon4w.hotpot.soups.recipes.ingredients.HotpotSoupIngredients;
import com.github.argon4w.hotpot.soups.recipes.ingredients.IHotpotSoupIngredientCondition;
import com.github.argon4w.hotpot.soups.recipes.ingredients.IHotpotSoupIngredientConditionSerializer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;

public record HotpotSoupContentCondition(String contentName) implements IHotpotSoupIngredientCondition {
    @Override
    public boolean matches(IHotpotContent content, IHotpotSoup soup) {
        return content.getID().equals(contentName);
    }

    @Override
    public IHotpotSoupIngredientConditionSerializer<?> getSerializer() {
        return HotpotSoupIngredients.CONTENT_CONDITION_SERIALIZER.get();
    }

    public static class Serializer implements IHotpotSoupIngredientConditionSerializer<HotpotSoupContentCondition> {
        @Override
        public HotpotSoupContentCondition fromJson(JsonObject jsonObject) {
            if (!jsonObject.has("content_name")) {
                throw new JsonParseException("Content condition must have a \"content_name\"");
            }

            return new HotpotSoupContentCondition(GsonHelper.getAsString(jsonObject, "content_name"));
        }

        @Override
        public HotpotSoupContentCondition fromNetwork(FriendlyByteBuf byteBuf) {
            return new HotpotSoupContentCondition(byteBuf.readUtf());
        }

        @Override
        public void toNetwork(FriendlyByteBuf byteBuf, HotpotSoupContentCondition condition) {
            byteBuf.writeUtf(condition.contentName);
        }

        @Override
        public ResourceLocation getType() {
            return new ResourceLocation(HotpotModEntry.MODID, "content");
        }
    }
}
