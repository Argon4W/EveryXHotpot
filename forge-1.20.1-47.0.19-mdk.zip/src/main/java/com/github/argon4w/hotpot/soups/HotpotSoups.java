package com.github.argon4w.hotpot.soups;

import com.github.argon4w.hotpot.HotpotModEntry;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.registries.RegistryBuilder;
import net.minecraftforge.registries.RegistryObject;

import java.util.function.*;

public class HotpotSoups {
    public static final ResourceLocation EMPTY_SOUP_LOCATION = new ResourceLocation(HotpotModEntry.MODID, "empty_soup");

    public static final ResourceKey<Registry<IHotpotSoupHolder<?>>> SOUP_REGISTRY_KEY = ResourceKey.createRegistryKey(new ResourceLocation(HotpotModEntry.MODID, "soup"));
    public static final DeferredRegister<IHotpotSoupHolder<?>> SOUPS = DeferredRegister.create(SOUP_REGISTRY_KEY, HotpotModEntry.MODID);
    public static final Supplier<IForgeRegistry<IHotpotSoupHolder<?>>> SOUP_REGISTRY = SOUPS.makeRegistry(() -> new RegistryBuilder<IHotpotSoupHolder<?>>().setDefaultKey(EMPTY_SOUP_LOCATION));

    public static final RegistryObject<IHotpotSoupHolder<HotpotClearSoup>> CLEAR_SOUP = SOUPS.register("clear_soup", () -> HotpotClearSoup::new);
    public static final RegistryObject<IHotpotSoupHolder<HotpotSpicySoup>> SPICY_SOUP = SOUPS.register("spicy_soup", () -> HotpotSpicySoup::new);
    public static final RegistryObject<IHotpotSoupHolder<HotpotCheeseSoup>> CHEESE_SOUP = SOUPS.register("cheese_soup", () -> HotpotCheeseSoup::new);
    public static final RegistryObject<IHotpotSoupHolder<HotpotSmeltingRecipeSoup>> LAVA_SOUP = SOUPS.register("lava_soup", () -> HotpotSmeltingRecipeSoup::new);
    public static final RegistryObject<IHotpotSoupHolder<HotpotTomatoSoup>> TOMATO_SOUP = SOUPS.register("tomato_soup", () -> HotpotTomatoSoup::new);
    public static final RegistryObject<IHotpotSoupHolder<HotpotEmptySoup>> EMPTY_SOUP = SOUPS.register("empty_soup", () -> HotpotEmptySoup::new);

    public static IHotpotSoupHolder<HotpotEmptySoup> getEmptySoup() {
        return EMPTY_SOUP.get();
    }

    public static IForgeRegistry<IHotpotSoupHolder<?>> getSoupRegistry() {
        return SOUP_REGISTRY.get();
    }

    public static IHotpotSoupHolder<?> getSoupType(ResourceLocation resourceLocation) {
        return getSoupRegistry().getValue(resourceLocation);
    }
}
