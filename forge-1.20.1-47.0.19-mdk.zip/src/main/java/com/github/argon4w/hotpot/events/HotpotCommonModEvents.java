package com.github.argon4w.hotpot.events;

import com.github.argon4w.hotpot.HotpotModEntry;
import com.github.argon4w.hotpot.soups.HotpotSoupManager;
import net.minecraftforge.event.AddReloadListenerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Optional;

@Mod.EventBusSubscriber(modid = HotpotModEntry.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class HotpotCommonModEvents {
    private static HotpotSoupManager HOTPOT_SOUP_VARIANT_MANAGER;

    @SubscribeEvent
    public static void onAddReloadListener(AddReloadListenerEvent event) {
        event.addListener(HOTPOT_SOUP_VARIANT_MANAGER = new HotpotSoupManager(event.getConditionContext()));
    }

    public static Optional<HotpotSoupManager> getSoupVariantManager() {
        return Optional.ofNullable(HOTPOT_SOUP_VARIANT_MANAGER);
    }
}
